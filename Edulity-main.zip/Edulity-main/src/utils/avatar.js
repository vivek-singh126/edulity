
export const randomnum(num){
    return Math.floor(Math.random()*9999);
}
