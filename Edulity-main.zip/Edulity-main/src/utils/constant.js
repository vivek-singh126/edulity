
export const Account_type={
    instructor:'Instructor',
    admin:'Admin',
    student:'Student'
}

export const Publish_type={
    publish:'Published',
    draft:'Draft'
}