export const buycarddata=[
    "On-demand video",
    "Full Lifetime access",
    "Access on Mobile and TV",
    "Certificate of completion"
    
]

